﻿/* Nathan Peereboom
 * March 22, 2019
 * Generated dart board.
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _312840BullsEye
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 15; i >= 0; i--)
            {
                Ellipse c = new Ellipse();
                c.Height = i * 50;
                c.Width = i * 50;
                if (i % 2 == 0)
                {
                    c.Fill = Brushes.White;
                }
                else
                {
                    c.Fill = Brushes.Red;
                }
                canvas.Children.Add(c);
                Canvas.SetTop(c, 400 - (c.Width/2));
                Canvas.SetLeft(c, 400 - (c.Width/2));
            }
        }
    }
}
