﻿/* Nathan Peereboom
 * March 22, 2019
 * Working on the graphic for the fibaonacci seqence. Currently trying to figure out the positioning of the rectangles.
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _312840FibonacciSequence
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            int x = 0; int y = 1;
            int output;
            for (int i = 0; i < 8; i++)
            {
                output = x + y;
                Rectangle r = new Rectangle();
                r.Height = output * 10;
                r.Width = output * 10;
                r.Fill = Brushes.Red;
                r.Stroke = Brushes.Black;
                canvas.Children.Add(r);
                if (i % 4 == 0)
                {
                    Canvas.SetTop(r, 400 - (r.Height / 2));
                    Canvas.SetLeft(r, 400 - (r.Width / 2));

                }
                else if (i % 4 == 1)
                x = y;
                y = output;
            }
        }
    }
}
 