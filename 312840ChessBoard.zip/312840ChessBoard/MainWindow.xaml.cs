﻿/* Nathan Peereboom
 * March 22, 2019
 * Generated chess board. Checkmate!
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _312840ChessBoard
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            for (int y = 0; y <= 7; y++)
            {
                for (int x = 0; x <= 7; x++)
                {
                    Rectangle r = new Rectangle();
                    r.Height = 100;
                    r.Width = 100;
                    if ((x + y) % 2 == 0)
                    {
                        r.Fill = Brushes.Black;
                    }
                    else
                    {
                        r.Fill = Brushes.LightGray;
                    }
                    canvas.Children.Add(r);
                    Canvas.SetLeft(r, x * 100);
                    Canvas.SetTop(r, y * 100);
                }
            }
        }
    }
}
